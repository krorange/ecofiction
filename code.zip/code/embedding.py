from gensim.models import Word2Vec
from gensim.utils import simple_preprocess
import os

sentences = []
root_dir = '/media/secure_volume/workset'

for filename in os.listdir(root_dir):
	if filename.endswith('.txt') and filename != 'volume-rights.txt':
		with open(os.path.join(root_dir, filename), encoding='utf-8') as f:
			for line in f:
				tokens = simple_preprocess(line)
				if tokens:
					sentences.append(tokens)
					
model = Word2Vec(sentences, vector_size=100, window=5, min_count=5, workers=4)

model.save("/media/secure_volume/word2vec_ecofiction.model")

print(model.wv.most_similar("build"))
