import glob, os
dictionary = {}

for s in glob.glob('/media/secure_volume/output/*.supersense'):
	first = True
	fn = os.path.basename(s).split('.')[0]
	dictionary[fn]={}
	for line in open(s).read().split('\n'):
		if line.strip() == '':
			continue
		if first:
			first = False
			continue
		row = line.split('\t')
		begin = int(row[0])
		end = int(row[1])
		for i in range(begin, end+1):
			dictionary[fn][i] = row[2]

for t in glob.glob('/media/secure_volume/output/*.tokens'):
	first = True
	fn = os.path.basename(t).split('.')[0]
	for token in open(t).read().split('\n'):
		if token.strip() == '':
			continue
		if first:
			first = False
			header = "document_id\t" + token.strip() + "\tsupersense_category"
			print(header)
			continue
		row = token.split('\t')
		token_id = int(row[3])
		supersense = '_'
		if token_id in dictionary[fn]:
			supersense = dictionary[fn][token_id]
		row.append(supersense)
		print('\t'.join([fn] + row))
