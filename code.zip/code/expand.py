from gensim.models import Word2Vec
import spacy
import os

model = Word2Vec.load("/media/secure_volume/word2vec_ecofiction.model")
nlp = spacy.load('en_core_web_sm')

def load_verbs(path):
	with open(path) as f:
		return [line.strip().lower() for line in f if line.strip()]

def is_verb(word):
	doc = nlp(word)
	return doc[0].pos_ == 'VERB'

def expand_verbs(seed_verbs, model, topn=15, similarity_threshold=0.5):
	expanded = set(seed_verbs)
	for verb in seed_verbs:
		if verb in model.wv:
			try:
				similar = model.wv.most_similar(verb, topn=topn)
				for word, score in similar:
					if score >= similarity_threshold and word.isalpha() and is_verb(word):
						expanded.add(word.lower())
			except KeyError:
				continue
	return expanded

agentic_seeds = load_verbs("Downloads/agency.txt")
experiencer_seeds = load_verbs("Downloads/experience.txt")

expanded_agentic = expand_verbs(agentic_seeds, model)
expanded_experiencer = expand_verbs(experiencer_seeds, model)

with open('/media/secure_volume/expanded_agency.txt', 'w') as f:
	f.write('\n'.join(expanded_agentic))
with open('/media/secure_volume/expanded_experience.txt', 'w') as f:
	f.write('\n'.join(expanded_experiencer))

