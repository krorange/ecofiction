# Count the number of agentic/experiencer verbs in a BookNLP .complete file
# `.complete` file = `.token` file + `.supersense` file

import csv

# Paths
input_path = '/media/secure_volume/all.complete'
output_path = '/media/secure_volume/nonhuman_verbs.csv'
agency_path = '/media/secure_volume/expanded_agency.txt'
experience_path = '/media/secure_volume/expanded_experience.txt'

# Verb lists
with open(agency_path, 'r', encoding='utf-8') as f:
	agency_verbs = set(line.strip() for line in f if line.strip())
with open(experience_path, 'r', encoding='utf-8') as f:
	experience_verbs = set(line.strip() for line in f if line.strip())

# Create output file
with open(output_path, 'w', newline='', encoding='utf-8') as csvfile:
	writer = csv.writer(csvfile)
	writer.writerow(['doc_id', 'lemma', 'supersense', 'matched_verb', 'verb_type', 'sentence'])
	
	with open(input_path, 'r', encoding='utf-8') as fd:
		line = fd.readline()
		current_sentence = []
		current_sentence_id = 0
		
		while line:
			if 'sentence_ID' in line:
				line = fd.readline()	# skip first row
				continue
				
			row = line.strip().split('\t')
			sentence_id = int(row[2])
			doc_id = row[0]
			
			if sentence_id != current_sentence_id and current_sentence:
				for sentence_row in current_sentence:
					supersense = sentence_row[14]
					dep = sentence_row[11]
					lemma = sentence_row[6]
					
					if supersense in {'noun.animal', 'noun.plant'} and dep == 'nsubj':
						syntactic_head_id = sentence_row[12]
						head_token = None
						
						for r in current_sentence:
							if r[4] == syntactic_head_id:
								head_token = r
								break
						if head_token:
							head_lemma = head_token[6]
							sentence_text = ' '.join([r[5] for r in current_sentence])
							
							if head_lemma in agency_verbs:
								writer.writerow([doc_id, lemma, supersense, head_lemma, 'agency', sentence_text])
							elif head_lemma in experience_verbs:
								writer.writerow([doc_id, lemma, supersense, head_lemma, 'experience', sentence_text])
				
				current_sentence = []

			current_sentence.append(row)
			current_sentence_id = sentence_id
			line = fd.readline()
