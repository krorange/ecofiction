# Count the number of animal/plant subjects (nsubj) in a BookNLP .complete file
# `.complete` file = `.token` file + `.supersense` file

import csv
from collections import defaultdict

current_sentence_id = 0
current_sentence = []

# Concatenated file of token and supersense
input_dir = '/media/secure_volume/all.complete'
fd = open(input_dir)
line = fd.readline()

# Default number of entities
counts = defaultdict(lambda: defaultdict(lambda: {'animal': 0, 'plant': 0}))

while line:
	if 'sentence_ID' in line:
		line = fd.readline()
		
	row = line.strip().split('\t')
	sentence_id = int(row[2])
	document_id = row[0]
	
	if sentence_id != current_sentence_id:
		# the previous sentence
		for sentence_row in current_sentence:
			doc_id = sentence_row[0]
			supersense = sentence_row[14]
			dep = sentence_row[11]
			lemma = sentence_row[6]
			if supersense == 'noun.animal' and dep == 'nsubj':
				#print(current_sentence_id,':::',' '.join([i[5] for i in current_sentence]))
				counts[doc_id][lemma]['animal'] += 1
				break
			if supersense == 'noun.plant' and dep == 'nsubj':
				#print(current_sentence_id,';;;',' '.join([i[5] for i in current_sentence]))
				counts[doc_id][lemma]['plant'] += 1
				break
		# a new sentence
		current_sentence = []
		current_sentence_id = sentence_id
	current_sentence.append(row)
	line = fd.readline()

output_dir = '/media/secure_volume/nonhuman_counts.csv'
with open(output_dir, 'w', newline='', encoding='utf-8') as csvfile:
	writer = csv.writer(csvfile)
	writer.writerow(['doc_id', 'token', 'count', 'supersense'])
	for doc_id, token_dict in counts.items():
		for token, supersense_counts in token_dict.items():
			animal_count = supersense_counts.get('animal', 0)
			plant_count = supersense_counts.get('plant', 0)
			if animal_count > 0:
				writer.writerow([doc_id, token, animal_count, 'animal'])
			if plant_count > 0:
				writer.writerow([doc_id, token, plant_count, 'plant'])
